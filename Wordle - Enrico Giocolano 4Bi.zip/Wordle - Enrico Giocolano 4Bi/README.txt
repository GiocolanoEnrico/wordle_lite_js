Per un corretto uso si consiglia di aprire solo il file HTML col proprio browser.

-Enrico Giocolano classe 4Bi ITIS Leonardo Da Vinci anno scolastico 2023/2024.